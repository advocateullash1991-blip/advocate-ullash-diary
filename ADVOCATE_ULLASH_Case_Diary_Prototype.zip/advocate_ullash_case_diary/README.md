# ADVOCATE ULLASH – Digital Case Diary (Prototype)

## কী আছে
- বাংলা responsive dashboard
- মামলা এন্ট্রি, তালিকা ও সার্চ
- পরবর্তী তারিখ ও মামলার অবস্থা
- দৈনিক কেস ডায়েরি এন্ট্রি
- PWA manifest ও service worker

## চালানোর নিয়ম
1. ZIP extract করুন।
2. `index.html` ব্রাউজারে খুলে UI পরীক্ষা করুন।
3. PWA install ও offline cache ঠিকভাবে চালাতে HTTPS-এ host করতে হবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি প্রথম UI prototype। ডেটা browser-এর localStorage-এ থাকে। তাই:
- অন্য মোবাইল/কম্পিউটারে তথ্য নিজে থেকে sync হবে না।
- Admin/Assistant login এখনো যুক্ত নয়।
- এই সংস্করণে বাস্তব মামলার গোপন তথ্য দেবেন না।

## Production-এ নেওয়ার পরবর্তী কাজ
- Supabase/Firebase-এ secure cloud database ও authentication
- Admin এবং সর্বোচ্চ ২টি assistant account
- Role-based access control ও audit log
- Encrypted file storage, backup/restore
- Hearing reminders/notifications
- HTTPS hosting, domain ও privacy policy

Production deployment-এর আগে database security rules ও backup restore পরীক্ষা করা বাধ্যতামূলক।
